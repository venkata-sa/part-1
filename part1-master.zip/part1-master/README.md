# part1
